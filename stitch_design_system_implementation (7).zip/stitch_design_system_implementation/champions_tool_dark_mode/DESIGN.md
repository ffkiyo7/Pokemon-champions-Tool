---
name: Champions Tool - Dark Mode
colors:
  surface: '#121319'
  surface-dim: '#121319'
  surface-bright: '#38393f'
  surface-container-lowest: '#0c0e14'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#282a30'
  surface-container-highest: '#33343b'
  on-surface: '#e2e2ea'
  on-surface-variant: '#c4c6d4'
  inverse-surface: '#e2e2ea'
  inverse-on-surface: '#2f3036'
  outline: '#8e909d'
  outline-variant: '#434652'
  surface-tint: '#b3c5ff'
  primary: '#b3c5ff'
  on-primary: '#002b75'
  primary-container: '#7c9fff'
  on-primary-container: '#003286'
  inverse-primary: '#3359b5'
  secondary: '#bac6e8'
  on-secondary: '#24304b'
  secondary-container: '#3b4663'
  on-secondary-container: '#a9b5d6'
  tertiary: '#efc134'
  on-tertiary: '#3d2e00'
  tertiary-container: '#c89d00'
  on-tertiary-container: '#483700'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#12419c'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#bac6e8'
  on-secondary-fixed: '#0e1b35'
  on-secondary-fixed-variant: '#3b4663'
  tertiary-fixed: '#ffdf91'
  tertiary-fixed-dim: '#efc134'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#121319'
  on-background: '#e2e2ea'
  surface-variant: '#33343b'
  page-bg: '#141414'
  card-surface: '#1e1e1e'
  card-border: '#2a2a2a'
  elevated-surface: '#262626'
  secondary-bg: '#1a1a1a'
  text-primary: '#ececec'
  text-secondary: '#8a8a8a'
  text-muted: '#555555'
  accent-ice-blue: '#7c9fff'
  status-success: '#3dba7e'
  status-danger: '#e05252'
  status-warning: '#d4870a'
  divider: '#242424'
  disabled: '#3a3a3a'
  badge-legal-bg: '#0d2b1e'
  badge-review-bg: '#2b1f08'
  badge-missing-bg: '#2b1010'
typography:
  page-title:
    fontFamily: DM Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: '1.2'
  card-label:
    fontFamily: DM Sans
    fontSize: 11px
    fontWeight: '400'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  card-value:
    fontFamily: DM Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: '1.4'
  emphasis-number:
    fontFamily: DM Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: '1.1'
  body-main:
    fontFamily: DM Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  body-secondary:
    fontFamily: DM Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
  small-caps:
    fontFamily: DM Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  page-margin: 16px
  card-padding: 12px
  element-gap: 8px
  tight-gap: 4px
  section-margin: 24px
---

# Champions Tool · Stitch Design Prompt（暗色版）
> 竞技宝可梦对战助手 PWA · Regulation Set M-A · Dark Theme

---

## VISUAL FOUNDATION

**设计参考**

整体色调参考 Claude app 暗色模式与 ChatGPT 深色模式的共同语言：
不使用纯黑，而是**有温度的深冷灰**，层次通过三个可感知的色阶建立——
页面底 → 卡片面 → 悬停态，每层有明确差异但不依赖投影。

**Color system**

| Token | Value | 用途 |
|---|---|---|
| Page background | `#141414` | 页面底色（近黑，带极轻冷调） |
| Card surface | `#1e1e1e` | 卡片面（参考 ChatGPT 卡片深度） |
| Card border | `#2a2a2a` | 卡片边框（微妙，不抢眼） |
| Elevated surface | `#262626` | 悬停、展开、bottom sheet |
| Secondary bg | `#1a1a1a` | Tab栏、section 分组区 |
| Primary text | `#ececec` | 主文字（非纯白，减少刺眼） |
| Secondary text | `#8a8a8a` | 次级文字 |
| Muted text | `#555555` | 占位、禁用文字 |
| Accent | `#7c9fff` | 冰蓝强调色（低饱和，高级感） |
| Accent subtle | `#1e2a45` | Accent 背景层（深色底上的浅蓝区域） |
| Success / faster | `#3dba7e` | 速度更快、合法状态 |
| Danger / slower | `#e05252` | 速度更慢、危险状态 |
| Warning / review | `#d4870a` | 待复核、警告 |
| Divider | `#242424` | 分割线 |
| Disabled | `#3a3a3a` | 禁用状态 |

**类型徽章**：使用标准宝可梦属性色，在深色底上略微降低亮度（约 85%），
避免过于荧光。徽章背景使用属性色的 15% 透明度深色叠加层。

**Typography**

- 字体：DM Sans 或系统 sans-serif
- 页面标题：17px semibold · `#ececec`
- 卡片标签：11px regular · `#8a8a8a` · 全大写 + 字间距
- 卡片数值：14–16px semibold · `#ececec`
- 强调数字：22–28px bold · `#ffffff`（伤害百分比、速度值，用纯白区分层级）
- 宝可梦名：中文名为主 · 英文名 12px `#8a8a8a` 同行跟随

例：`烈咬陆鲨 Garchomp` · `炽焰咆哮虎 Incineroar`

**Spacing rhythm**

页面边距 16px · 卡片内边距 12px · 元素间距 8px

---

## COMPONENT LIBRARY

### BADGE（状态徽章）
pill 形状 · 5px radius · 11px 文字
深色底上徽章用**深色填充 + 亮色文字**，不用浅色背景

| 状态 | 背景色 | 文字色 |
|---|---|---|
| 合法 | `#0d2b1e` | `#3dba7e` |
| 需复核 | `#2b1f08` | `#d4870a` |
| 缺少配置 | `#2b1010` | `#e05252` |
| 规则版本 | `#1e2a45` | `#7c9fff` |
| 当前赛季 | `#1e2a45` | `#7c9fff` |

### CHIP（筛选/标签）
6px radius · 12px 文字 · 边框 `#2a2a2a`

- Active：`#7c9fff` 背景 · `#141414` 文字（深色文字在冰蓝底上）
- Default：`#1e1e1e` 背景 · `#8a8a8a` 文字 · 边框 `#2a2a2a`

### CARD
背景 `#1e1e1e` · 10px radius · 1px 边框 `#2a2a2a` · 12px 内边距
无投影。深色系层次完全靠色阶区分，不加任何 box-shadow。

### BOTTOM SHEET
从底部滑出 · 顶部 16px radius · drag handle（32px · `#3a3a3a` pill）
背景：`#1e1e1e`，顶部边框线 `#2a2a2a`

### ACTION BUTTON（行内按钮）
28px 高度 · 8px radius · 12px 文字

- Primary：`#7c9fff` 背景 · `#141414` 文字
- Ghost：透明背景 · `#7c9fff` 文字 · 1px 边框 `#7c9fff` at 40% opacity

### BOTTOM TAB BAR
背景 `#1a1a1a` · 1px 顶部边框 `#242424` · 5 个 tab

- Active：图标 + 标签 `#7c9fff` · 图标下方 3px 圆点，颜色 `#7c9fff`
- Inactive：`#555555`
- 不使用背景色填充 active 状态

### SYNC STATUS STRIP
全宽 · 36px 高度 · 12px 文字

| 状态 | 背景 | 样式 |
|---|---|---|
| 已同步 | `#0d2b1e` | `#3dba7e` 圆点 · "数据已同步 · v2.1.0 · 3小时前" |
| 可刷新 | `#2b1f08` | `#d4870a` 圆点 · "数据可更新" + [刷新] ghost 按钮 |
| 离线中 | `#1e1e1e` | `#3a3a3a` 圆点 · "使用本地缓存" · `#555555` 文字 |

---

## LANGUAGE

- 主界面语言：简体中文
- 宝可梦名称：中文名主要显示，英文名 12px 次级色同行跟随
- 不暗示完整合法列表，使用 4–6 个真实占位宝可梦
- 所有计算结果标注：`示例数据 · 非真实计算`

**占位宝可梦**：烈咬陆鲨 Garchomp · 炽焰咆哮虎 Incineroar · 小顿熊 Cetitan · コータス Torkoal · 水君 Politoed

---

## SCREEN 1 · 首页

无 hero 区域，打开即进入数据。

**顶部区域（约 80px）**
- 左：`Champions Tool` wordmark 16px semibold · `#ececec`
- 右：齿轮图标 · `#8a8a8a`
- Wordmark 下方：SYNC STATUS STRIP（默认显示「已同步」状态，标注「可刷新」作为备用状态）

**规则信息卡片**（`#1e1e1e` 卡片，全宽）
- Row 1：`Regulation Set M-A` 16px bold `#ececec` · BADGE「当前赛季」
- Row 2：三个 info chip 横排：`双打为主` · `Mega 可用` · `Lv.50`
- Row 3：`有效期 2025.03 – 2025.08` 12px `#8a8a8a`
- Row 4：`官方数据源 ✓` 12px `#3dba7e`

**快捷入口 2×2 网格**
每格：`#1e1e1e` 卡片 · 24px line 风格图标（`#7c9fff`）+ 中文标签 `#ececec` + 单行描述 `#8a8a8a`

```
[组队]   管理你的对战队伍    [计算]  伤害与击杀计算
[速度线] 快慢比较基准        [图鉴]  规则内图鉴查询
```

---

## SCREEN 2 · 组队

**顶部**：`我的队伍` `#ececec` + `[+ 新建]` Primary 按钮
多支队伍时显示横向滚动 tab。

**队伍成员列表**：6 个卡片槽位

每张成员卡片（紧凑，全宽，`#1e1e1e` 背景）：
- 左列（40px）：宝可梦图标圆形占位 · `#262626` 背景圆
- 中列：
  - Line 1：中英文名 · BADGE（合法 / 复核 / 缺少配置）
  - Line 2：道具名 · 特性名 · 性格 · `#8a8a8a`
  - Line 3：4 个招式 pill（`#262626` 背景 · `#8a8a8a` 文字）
- 右列：chevron 图标 · `#3a3a3a`

**展开状态**（展示一张点击展开的卡片，背景升至 `#262626`）：
- 6 条横向迷你进度条（HP / 攻 / 防 / 特攻 / 特防 / 速）
- 带标签和数值，进度条色：`#7c9fff`，底色：`#2a2a2a`
- 操作行：`[→ 伤害计算]` `[→ 速度线]`（ghost 按钮）

**空状态**（内嵌在列表区，非全屏）：
图标 `#3a3a3a` + `还没有队伍` `#8a8a8a` + `[新建第一支队伍]` Primary 按钮

**队伍分析条**（固定在列表下方、tab 栏上方，`#1a1a1a` 背景）：
横向滚动的摘要 chip 行：
`属性弱点 ×2` · `物攻倾向` · `速度覆盖` · `缺少回复位`
每个 chip 点击展开 bottom sheet 详情。

---

## SCREEN 3 · 伤害计算

**选择器行**（三段连接 pill，全宽）：
```
[进攻方 ▾]  →  [招式 ▾]  →  [防守方 ▾]
```
pill 样式：`#1e1e1e` 背景 · 边框 `#2a2a2a` · 文字 `#ececec`
箭头图标：`#3a3a3a`

**条件行**（横向滚动 chip，选择器下方）：
`双打` · `分散伤害` · `天气 ▾` · `场地 ▾` · `能力± ▾` · `Mega状态`
激活 chip：`#7c9fff` 背景 · `#141414` 文字

**结果卡片**（突出，约占屏幕 45% 高度，`#1e1e1e` 卡片）：
- 顶部标签：`伤害计算结果` 11px `#8a8a8a`
- 大字居中：`68.4% – 80.7%` 28px bold `#ffffff`
- 副文：`103 – 121 伤害  /  对方 HP: 149` 13px `#8a8a8a`
- 分割线 `#242424`
- 确认率横排（3 格）：

  | 一确 | 二确 ✓ | 乱数 |
  |---|---|---|
  | `#555555` 文字 | **`#7c9fff` 背景 · `#141414` 文字** | `#555555` 文字 |

- 底部：`示例数据 · 非真实计算 · 数据 v2.1.0` 11px `#555555`

**阻断状态**（覆盖在结果卡片上）：
`#2b1f08` 背景 · `#d4870a` 图标 + 文字
`该机制待确认，计算暂不可用` + `[了解详情]` `#d4870a` 链接

---

## SCREEN 4 · 速度线

**视觉重点屏，给予最多细节和空间。**

**顶部控件**（紧凑，2 行）：
- Row 1：`[宝可梦选择器 ▾]`（`#1e1e1e` pill）→ 已选示例：`烈咬陆鲨 Garchomp` `#ececec`
- Row 2：横向滚动 chip：`怕慢(+速)` · `EV:252` · `Mega形态` · `道具 ▾` · `追风`

**速度值显示**：
- 大字：`最终速度 163` 24px bold `#ffffff`
- 副文：`基础速度 102 · 性格×1.1 · EV+84` 12px `#8a8a8a`

**筛选 tab**（控件下方）：
`当前队伍` · `收藏` · `常见` · `全部`
默认激活：`常见`（`#7c9fff` 下划线）

---

### 速度轴（主视觉，约 200px 高度）

水平标尺，占全宽，`#141414` 区域背景。

**X 轴**：最终 Lv.50 速度值
- 刻度标签：`50` · `100` · `150` · `200` · `250` · `#555555` 文字
- 轴线：1.5px `#2a2a2a` · 每 25 单位一个刻度（`#242424`）

**当前宝可梦 marker**：
- 轴上方：竖线（1px `#7c9fff` at 60% opacity）向上
- 菱形 marker 在轴上 · 24px 头像圆形在竖线顶端（`#1e2a45` 背景圆）
- 轴下方：速度值标签 `163` · `#7c9fff` bold
- 颜色：全部使用 `#7c9fff` accent

**Benchmark markers**（约 6 个，`常见` 筛选下）：
- 轴上方 stagger 错位（防止标签重叠）：**慢于当前** → `#e05252` 实心圆点 + 标签
- 轴下方 stagger 错位：**快于当前** → `#3dba7e` 实心圆点 + 标签
- 标签格式：`最速コータス` 10px · 颜色同圆点
- marker：8px 实心圆
- 轴区域背景可加极轻微的横向渐变：左侧 `#0d2b1e` at 5% → 中部透明 → 右侧 `#2b1010` at 5%
  （给速度轴增加快/慢的环境感，非常克制）

**轴图例**（轴区域底部）：
`● #3dba7e 我更快` · `● #e05252 我更慢` · `◆ #7c9fff 当前`
文字 `#555555`

---

**Benchmark bottom sheet**（点击 marker 后滑出）：
- 背景 `#1e1e1e` · drag handle `#3a3a3a`
- 标题行：`最速コータス` `#ececec` 16px + `[★ 收藏]` 图标 `#8a8a8a`
- 信息网格（两列，标签 `#8a8a8a` · 值 `#ececec`）：

  ```
  宝可梦:   コータス Torkoal    形态:    原始形态
  性格:     怕慢(+速)           速度EV:  252
  最终速度:  115                道具:    精华宝果
  来源:     VGC 2025 常见基准   标签:    [天气队] [基准]
  ```

- 备注：`在晴天队中高频使用的基准点` · `#8a8a8a`
- 底部分割线 `#242424`

---

## SCREEN 5 · 图鉴

**子 tab 行**：`Pokémon` · `招式` · `道具` · `特性`
激活状态：`#7c9fff` 下划线 · 文字 `#ececec`
非激活：`#555555`

**搜索栏**：`#1e1e1e` 背景 · 边框 `#2a2a2a` · placeholder `搜索名称或属性` `#555555`
**属性筛选 chip**（横向滚动）：`全部` · `火` · `水` · `草` · …

---

### Pokémon tab — 列表视图

每行（紧凑，60px，`#1e1e1e` 底色，分割线 `#242424`）：
- 左：36px 图标圆形（`#262626` 背景）+ 属性徽章（2 个 pill）
- 中：中英文名 `#ececec` · `速度 102` `#8a8a8a`
- 右：合法徽章 + chevron `#3a3a3a`

### Pokémon tab — 详情视图

- 顶部：56px 图标（`#262626` 背景圆）· 中英文名 `#ececec` · 属性徽章
- 合法状态 chip 行：BADGE `M-A 合法` · CHIP `Mega 可用`
- 种族值卡片（`#1e1e1e`，紧凑）：6 条横向进度条
  - 进度条底色：`#2a2a2a`
  - 进度条颜色：低值 `#e05252` → 中值 `#7c9fff` → 高值 `#3dba7e`（按数值映射）
  - 标签 `#8a8a8a` · 数值 `#ececec`
- 特性行：特性名 pill（`#262626` 背景）列表，可点击
- 招式区域：紧凑横向滚动 pill 网格（`#262626` 背景）
- 快捷操作（3 个 ghost 按钮横排）：`[加入队伍]` `[→ 速度线]` `[→ 计算]`

---

### 招式 tab — 列表视图

每行：属性徽章 · 招式名 `#ececec` · 威力 · 命中 · PP `#8a8a8a` · 分类图标

### 道具 tab — 列表视图

每行：道具图标占位（`#262626` 圆）· 名称 `#ececec` · 合法徽章 · 效果 `#8a8a8a`

### 特性 tab — 列表视图

每行：特性名 `#ececec` · 效果摘要 `#8a8a8a` · `12个宝可梦` `#555555`

---

## SCREEN 6 · 设置

简洁分组列表。Section 标题 `#555555` 11px uppercase，
行内文字主 `#ececec` · 次 `#8a8a8a`，分割线 `#242424`。

**数据管理**
```
当前规则    Regulation Set M-A             →
数据版本    v2.1.0
上次同步    3小时前                    [立即刷新]
清除本地缓存                           [清除]  ← #e05252 文字色
```

**队伍数据**
```
导出队伍数据                                →
导入队伍数据                                →
```

**显示设置**
```
语言        中文优先，保留英文名            →
深色模式    ● （toggle，默认开启，#7c9fff 激活色）
```

**即将支持**（整组 `#3a3a3a` 文字，置灰）
```
多规则切换  [敬请期待]
```

---

## ERROR & EMPTY STATES

内嵌在对应屏幕中，不作为独立全屏。

| 场景 | 位置 | 样式 |
|---|---|---|
| 无队伍 | 组队屏列表区居中 | 图标 `#3a3a3a` + `还没有队伍` `#8a8a8a` + CTA 按钮 |
| 刷新失败 | 设置屏刷新按钮下方 | `#2b1f08` strip · `#d4870a` 文字：`刷新失败，当前使用本地缓存` |
| 搜索无结果 | 图鉴搜索结果区 | 图标 `#3a3a3a` + `没有找到相关内容` `#555555` |
| 机制待确认 | 计算屏结果卡片上覆盖 | `#2b1f08` 覆盖卡 · `#d4870a` 图标+文字（见 Screen 3） |
| 成员违规 | 组队屏成员卡片行内 | `#e05252` BADGE 替换合法 BADGE |

---

## OUTPUT INSTRUCTIONS

- 所有 6 个屏幕作为独立的 375px 手机帧，垂直排列展示
- 每帧顶部显示状态栏（时间 + 图标），底部显示 tab 栏
- 帧内背景色 `#141414`，无需手机硬件外壳
- 不使用 lorem ipsum，使用上方指定的占位宝可梦
- 所有计算数值标注为示例数据
- 每个屏幕至少内嵌展示一个 error / empty state
- 各屏信息密度不同：设置屏保持简洁，速度线屏是视觉核心，给予最多空间和细节
- 深色版特别注意：所有边框必须可见但克制，不得出现投影，层次感来自色阶而非光影效果
